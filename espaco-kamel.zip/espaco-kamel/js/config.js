/* =====================================================================
   DADOS DO ESPAÇO — edite aqui. A interface lê tudo deste arquivo.
   ===================================================================== */
window.SITE = {
  name: "Espaço Kamel Special Kids",

  whatsapp: "5561981733710",
  phoneDisplay: "(61) 98173-3710",
  phoneTel: "+5561981733710",
  // @ do Instagram, sem o @. Vazio = link escondido.
  instagram: "",

  address: {
    line1: "Av. das Castanheiras, Rua 24 Norte, lotes 09-11",
    line2: "Galeria La Belle, Loja 25",
    district: "Águas Claras",
    city: "Brasília",
    state: "DF",
    zip: "70297-400",
  },
  mapsQuery: "Espaço Kamel, Galeria La Belle, Av. das Castanheiras, Águas Claras, Brasília - DF",

  // Horários: só o fechamento (20h30) é conhecido. Preencha a lista.
  // Ex.: { days: "Segunda a sexta", text: "08h às 20h30" }
  hours: [],
  hoursNote: "Aberto até 20h30. Confirme dias e horários pelo WhatsApp.",

  messages: {
    general: "Olá! Conheci o Espaço Kamel pelo site e gostaria de saber como funciona o atendimento.",
    area: (a) => `Olá! Conheci o Espaço Kamel pelo site e gostaria de informações sobre ${a}.`,
  },

  /* Áreas de atendimento. Psicologia é a categoria do Google.
     As demais são EXEMPLOS comuns em clínicas multidisciplinares:
     mantenha só as que o espaço oferece e ajuste os textos. */
  areas: [
    { name: "Psicologia infantil", color: "blue", desc: "Acolhimento das emoções, do comportamento e das relações da criança, com orientação para a família." },
    { name: "Fonoaudiologia", color: "orange", desc: "Fala, linguagem, comunicação e alimentação, no tempo de cada criança." },
    { name: "Terapia ocupacional", color: "green", desc: "Autonomia nas atividades do dia a dia, coordenação e processamento sensorial." },
    { name: "Psicopedagogia", color: "magenta", desc: "Apoio às dificuldades de aprendizagem, em conversa com a escola." },
  ],

  // Avaliação no Google: 5,0 com 1 avaliação (sem comentário escrito).
  rating: { value: 5.0, count: 1 },

  // Deixe true enquanto as fotos forem de banco de imagens.
  illustrativePhotos: true,
};
