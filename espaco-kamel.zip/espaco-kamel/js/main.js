(function () {
  "use strict";

  var S = window.SITE;
  var doc = document;
  var root = doc.documentElement;
  root.classList.add("js");
  var reduceMQ = window.matchMedia("(prefers-reduced-motion: reduce)");

  function el(tag, cls, text) {
    var n = doc.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  function icon(id) {
    var svg = doc.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("class", "ico");
    svg.setAttribute("aria-hidden", "true");
    var use = doc.createElementNS("http://www.w3.org/2000/svg", "use");
    use.setAttribute("href", "#i-" + id);
    svg.appendChild(use);
    return svg;
  }
  function waLink(msg) { return "https://wa.me/" + S.whatsapp + "?text=" + encodeURIComponent(msg); }
  var q = encodeURIComponent(S.mapsQuery);
  var maps = {
    search: "https://www.google.com/maps/search/?api=1&query=" + q,
    route: "https://www.google.com/maps/dir/?api=1&destination=" + q,
    embed: "https://www.google.com/maps?q=" + q + "&z=17&output=embed",
  };

  /* ---------- Links e dados ---------- */
  doc.querySelectorAll("[data-wa]").forEach(function (a) { a.href = waLink(S.messages[a.dataset.wa] || S.messages.general); });
  doc.querySelectorAll("[data-maps]").forEach(function (a) { a.href = maps[a.dataset.maps]; });
  doc.querySelectorAll("[data-tel]").forEach(function (a) { a.href = "tel:" + S.phoneTel; a.textContent = S.phoneDisplay; });
  if (S.instagram) {
    doc.querySelectorAll("[data-insta]").forEach(function (a) { a.href = "https://www.instagram.com/" + S.instagram + "/"; });
    doc.querySelectorAll("[data-insta-item]").forEach(function (n) { n.hidden = false; });
  }
  var A = S.address;
  doc.querySelectorAll('[data-addr="line1"]').forEach(function (n) { n.textContent = A.line2; });
  doc.querySelectorAll('[data-addr="rest"]').forEach(function (n) {
    n.textContent = A.line1 + " · " + A.district + ", " + A.city + " - " + A.state + " · CEP " + A.zip;
  });
  doc.querySelectorAll('[data-addr="full"]').forEach(function (n) {
    [A.line2, A.line1, A.district + ", " + A.city + " - " + A.state, "CEP " + A.zip].forEach(function (l, i) {
      if (i) n.appendChild(doc.createElement("br"));
      n.appendChild(doc.createTextNode(l));
    });
  });
  var hours = doc.getElementById("hours");
  hours.textContent = S.hours.length
    ? S.hours.map(function (h) { return h.days + ": " + h.text; }).join(" · ")
    : S.hoursNote;
  doc.getElementById("year").textContent = new Date().getFullYear();
  if (!S.illustrativePhotos) doc.querySelectorAll("[data-illustrative]").forEach(function (n) { n.hidden = true; });

  /* ---------- Atendimentos ---------- */
  var grid = doc.getElementById("areas");
  S.areas.forEach(function (a) {
    var li = el("li", "area area--" + (a.color || "blue"));
    var link = el("a");
    link.href = waLink(S.messages.area(a.name));
    link.target = "_blank";
    link.rel = "noopener";
    link.setAttribute("aria-label", a.name + ". Tirar dúvidas pelo WhatsApp");
    link.appendChild(el("span", "area__badge", a.name.charAt(0)));
    link.appendChild(el("h3", null, a.name));
    link.appendChild(el("p", null, a.desc));
    var cta = el("span", "area__cta");
    cta.appendChild(doc.createTextNode("Tirar dúvidas"));
    cta.appendChild(icon("arrow"));
    link.appendChild(cta);
    li.appendChild(link);
    grid.appendChild(li);
  });

  /* ---------- Rede de pontos (a "constelação" do logo) ---------- */
  var COLORS = ["#d6337a", "#f39221", "#ffc93c", "#5db543", "#18a5c8", "#0a4bb0", "#7b4fa3"];
  function Net(canvas, opts) {
    this.c = canvas;
    this.ctx = canvas.getContext("2d");
    this.opts = opts;
    this.nodes = [];
    this.running = false;
    this.visible = false;
    this.resize();
    var self = this;
    window.addEventListener("resize", function () { self.resize(); });
  }
  Net.prototype.resize = function () {
    var r = this.c.getBoundingClientRect();
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.w = r.width; this.h = r.height;
    this.c.width = r.width * dpr; this.c.height = r.height * dpr;
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    var n = Math.round(Math.min(70, (this.w * this.h) / 16000));
    this.nodes = [];
    for (var i = 0; i < n; i++) {
      this.nodes.push({
        x: Math.random() * this.w, y: Math.random() * this.h,
        vx: (Math.random() - .5) * .25, vy: (Math.random() - .5) * .25,
        r: 2 + Math.random() * 3.5, c: this.opts.white ? "#ffffff" : COLORS[i % COLORS.length],
      });
    }
    this.draw();
  };
  Net.prototype.draw = function () {
    var ctx = this.ctx, N = this.nodes, max = 130;
    ctx.clearRect(0, 0, this.w, this.h);
    for (var i = 0; i < N.length; i++) {
      for (var j = i + 1; j < N.length; j++) {
        var dx = N[i].x - N[j].x, dy = N[i].y - N[j].y, d = Math.sqrt(dx * dx + dy * dy);
        if (d < max) {
          ctx.strokeStyle = this.opts.white ? "rgba(255,255,255," + (1 - d / max) * .5 + ")" : "rgba(10,75,176," + (1 - d / max) * .28 + ")";
          ctx.lineWidth = 1.2;
          ctx.beginPath(); ctx.moveTo(N[i].x, N[i].y); ctx.lineTo(N[j].x, N[j].y); ctx.stroke();
        }
      }
    }
    N.forEach(function (n) {
      ctx.fillStyle = n.c;
      ctx.beginPath(); ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2); ctx.fill();
    });
  };
  Net.prototype.step = function () {
    var self = this;
    if (!this.running || !this.visible) { this.raf = null; return; }
    this.nodes.forEach(function (n) {
      n.x += n.vx; n.y += n.vy;
      if (n.x < 0 || n.x > self.w) n.vx *= -1;
      if (n.y < 0 || n.y > self.h) n.vy *= -1;
    });
    this.draw();
    this.raf = requestAnimationFrame(function () { self.step(); });
  };
  Net.prototype.setRunning = function (on) {
    this.running = on;
    if (on && this.visible && !this.raf) this.step();
  };
  Net.prototype.setVisible = function (v) {
    this.visible = v;
    if (v && this.running && !this.raf) this.step();
  };

  var nets = [];
  [["net", false], ["net2", true]].forEach(function (cfg) {
    var c = doc.getElementById(cfg[0]);
    if (c && c.getContext) nets.push(new Net(c, { white: cfg[1] }));
  });
  if ("IntersectionObserver" in window) {
    var vis = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        nets.forEach(function (n) { if (n.c === e.target) n.setVisible(e.isIntersecting); });
      });
    });
    nets.forEach(function (n) { vis.observe(n.c); });
  } else {
    nets.forEach(function (n) { n.setVisible(true); });
  }

  /* ---------- Vídeo e botão "Pausar animações" ---------- */
  var video = doc.getElementById("hero-video");
  var vBtn = doc.getElementById("video-toggle");
  var mBtn = doc.getElementById("motion-toggle");
  function setVideoBtn() {
    var paused = video.paused;
    vBtn.setAttribute("aria-label", paused ? "Reproduzir vídeo" : "Pausar vídeo");
    vBtn.querySelector("use").setAttribute("href", paused ? "#i-play" : "#i-pause");
  }
  video.addEventListener("play", setVideoBtn);
  video.addEventListener("pause", setVideoBtn);
  vBtn.addEventListener("click", function () {
    if (video.paused) { var p = video.play(); if (p && p.catch) p.catch(function () {}); } else video.pause();
  });

  function applyMotion(calm) {
    root.classList.toggle("calm", calm);
    mBtn.setAttribute("aria-pressed", String(calm));
    mBtn.querySelector("span").textContent = calm ? "Retomar animações" : "Pausar animações";
    mBtn.title = calm ? "Retomar animações" : "Pausar animações";
    mBtn.querySelector("use").setAttribute("href", calm ? "#i-play" : "#i-pause");
    nets.forEach(function (n) { n.setRunning(!calm); });
    if (calm) video.pause();
    else { var p = video.play(); if (p && p.catch) p.catch(function () {}); }
    setVideoBtn();
  }
  var startCalm = root.classList.contains("calm") || reduceMQ.matches;
  applyMotion(startCalm);
  mBtn.addEventListener("click", function () {
    var calm = !root.classList.contains("calm");
    try { localStorage.setItem("kamel-motion", calm ? "off" : "on"); } catch (e) {}
    applyMotion(calm);
  });

  /* ---------- Cabeçalho e menu ---------- */
  var header = doc.querySelector(".header");
  var burger = doc.querySelector(".burger");
  var nav = doc.getElementById("menu");
  var floatBtn = doc.querySelector(".wa-float");
  var hero = doc.getElementById("inicio");
  function onScroll() {
    var y = window.scrollY;
    header.classList.toggle("is-scrolled", y > 8);
    floatBtn.classList.toggle("is-visible", y > hero.offsetHeight * .6);
  }
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();
  function setMenu(open) {
    burger.setAttribute("aria-expanded", String(open));
    burger.setAttribute("aria-label", open ? "Fechar menu" : "Abrir menu");
    nav.classList.toggle("is-open", open);
    doc.body.classList.toggle("menu-open", open);
    if (open) nav.querySelector("a").focus({ preventScroll: true });
  }
  burger.addEventListener("click", function () { setMenu(burger.getAttribute("aria-expanded") !== "true"); });
  nav.addEventListener("click", function (e) { if (e.target.closest("a")) setMenu(false); });
  doc.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && nav.classList.contains("is-open")) { setMenu(false); burger.focus(); }
  });
  window.matchMedia("(min-width: 961px)").addEventListener("change", function (m) { if (m.matches) setMenu(false); });

  /* ---------- Link ativo e revelação ---------- */
  if ("IntersectionObserver" in window) {
    var links = {};
    doc.querySelectorAll(".nav__list a").forEach(function (a) { links[a.hash.slice(1)] = a; });
    var spy = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (!e.isIntersecting || !links[e.target.id]) return;
        Object.keys(links).forEach(function (k) { links[k].removeAttribute("aria-current"); });
        links[e.target.id].setAttribute("aria-current", "true");
      });
    }, { rootMargin: "-45% 0px -50% 0px" });
    doc.querySelectorAll("main > section[id]").forEach(function (s) { spy.observe(s); });
    var rev = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add("is-in"); rev.unobserve(e.target); } });
    }, { rootMargin: "0px 0px -8% 0px" });
    doc.querySelectorAll(".reveal, .area, .hl").forEach(function (n) { rev.observe(n); });
  } else {
    doc.querySelectorAll(".reveal, .area, .hl").forEach(function (n) { n.classList.add("is-in"); });
  }

  /* ---------- Mapa sob demanda ---------- */
  doc.getElementById("map-load").addEventListener("click", function () {
    var f = doc.createElement("iframe");
    f.src = maps.embed;
    f.title = "Mapa: Espaço Kamel na Galeria La Belle, Águas Claras";
    f.loading = "lazy";
    f.referrerPolicy = "no-referrer-when-downgrade";
    var box = doc.getElementById("map");
    box.querySelector(".map__ph").remove();
    box.appendChild(f);
  });
})();
