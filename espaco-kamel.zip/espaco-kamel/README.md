# Espaço Kamel Special Kids · site

Site estático (HTML, CSS e JavaScript puro, sem build). Hospede a pasta em
qualquer serviço estático (Netlify, Vercel, GitHub Pages, Cloudflare Pages).
Ver localmente: `python3 -m http.server 8000` e abra http://localhost:8000

## Onde editar

| O quê | Onde |
|---|---|
| Áreas de atendimento | `js/config.js` → `areas` |
| Horários | `js/config.js` → `hours` |
| WhatsApp, telefone, Instagram, endereço | `js/config.js` |
| Vídeo do topo | `video/brincar.mp4` e `video/brincar.webm` (+ `brincar-poster.webp`) |
| Fotos | pasta `img/` (mesmos nomes, formato WebP) |

## Antes de publicar

1. **Áreas de atendimento**: só Psicologia é confirmada (categoria do Google). Fonoaudiologia, Terapia ocupacional e Psicopedagogia são exemplos: ajuste.
2. **Nome**: o logo diz "Espaço KAMEL"; o Google Maps diz "Espaço Karmel". Padronize no Google.
3. **Horários**: só se sabe que fecha às 20h30.
4. **Instagram**: preencha o @.
5. **Fotos**: as da galeria são do Unsplash (uso comercial livre). O vídeo do topo é o enviado pelo cliente: confirme que há autorização de imagem dos responsáveis pelas crianças que aparecem nele.
6. **Domínio**: troque `https://www.seudominio.com.br` em `index.html`, `robots.txt` e `sitemap.xml`.
